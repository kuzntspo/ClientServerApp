package com.example.clientserverapp;

public class Configs {
    protected static String dbHost = "std-mysql.ist.mospolytech.ru";
    protected static String dbPort = "3306";
    protected static String dbUser = "std_2009_quote";
    protected static String dbPass = "12112009Polina";
    protected static String dbName = "std_2009_quote";
}
